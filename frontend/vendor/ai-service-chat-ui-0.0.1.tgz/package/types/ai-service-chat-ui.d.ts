import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';

interface IntegrationDemoArtifact {
    readonly type: 'integration-demo';
    readonly id: string;
    readonly headline: string;
    readonly payload: {
        readonly name: string;
        readonly description: string;
    };
}
interface ChatDemoRendererContext {
    readonly $implicit: IntegrationDemoArtifact;
}

declare class ChatUiComponent {
    readonly bannerTitle: _angular_core.InputSignal<string>;
    readonly bannerDescription: _angular_core.InputSignal<string>;
    readonly artifact: _angular_core.InputSignal<IntegrationDemoArtifact | undefined>;
    readonly renderer: _angular_core.InputSignal<TemplateRef<ChatDemoRendererContext> | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChatUiComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChatUiComponent, "ai-chat-ui", never, { "bannerTitle": { "alias": "bannerTitle"; "required": true; "isSignal": true; }; "bannerDescription": { "alias": "bannerDescription"; "required": true; "isSignal": true; }; "artifact": { "alias": "artifact"; "required": false; "isSignal": true; }; "renderer": { "alias": "renderer"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class ChatDemoRendererDirective {
    readonly template: TemplateRef<ChatDemoRendererContext>;
    static ngTemplateContextGuard(_directive: ChatDemoRendererDirective, _context: unknown): _context is ChatDemoRendererContext;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChatDemoRendererDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ChatDemoRendererDirective, "ng-template[aiChatDemoRenderer]", ["aiChatDemoRenderer"], {}, {}, never, never, true, never>;
}

export { ChatDemoRendererDirective, ChatUiComponent };
export type { ChatDemoRendererContext, IntegrationDemoArtifact };
//# sourceMappingURL=ai-service-chat-ui.d.ts.map
