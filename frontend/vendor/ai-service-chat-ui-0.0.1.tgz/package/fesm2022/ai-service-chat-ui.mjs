import { NgTemplateOutlet } from '@angular/common';
import * as i0 from '@angular/core';
import { input, Component, inject, TemplateRef, Directive } from '@angular/core';

class ChatUiComponent {
    bannerTitle = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "bannerTitle" }] : /* istanbul ignore next */ []));
    bannerDescription = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "bannerDescription" }] : /* istanbul ignore next */ []));
    artifact = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "artifact" }] : /* istanbul ignore next */ []));
    renderer = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "renderer" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.6", ngImport: i0, type: ChatUiComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.6", type: ChatUiComponent, isStandalone: true, selector: "ai-chat-ui", inputs: { bannerTitle: { classPropertyName: "bannerTitle", publicName: "bannerTitle", isSignal: true, isRequired: true, transformFunction: null }, bannerDescription: { classPropertyName: "bannerDescription", publicName: "bannerDescription", isSignal: true, isRequired: true, transformFunction: null }, artifact: { classPropertyName: "artifact", publicName: "artifact", isSignal: true, isRequired: false, transformFunction: null }, renderer: { classPropertyName: "renderer", publicName: "renderer", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <section class="chat-ui">
      <div class="banner">
        <h1>{{ bannerTitle() }}</h1>
        <p>{{ bannerDescription() }}</p>
      </div>
      @if (artifact(); as demoArtifact) {
        <section class="artifact">
          <h2>{{ demoArtifact.headline }}</h2>
          @if (renderer(); as demoRenderer) {
            <ng-container
              [ngTemplateOutlet]="demoRenderer"
              [ngTemplateOutletContext]="{ $implicit: demoArtifact }"
            />
          } @else {
            <p class="fallback">Vorschau nicht verfügbar.</p>
          }
        </section>
      }
    </section>
  `, isInline: true, styles: [":host{display:block;min-width:0;font:inherit}.chat-ui{display:grid;gap:1.5rem;background:var(--ai-chat-background, #fff8f8);color:var(--ai-chat-text, #21191c);overflow-wrap:anywhere}.banner{padding:1.25rem;border-radius:1rem;background:var(--ai-chat-banner-background, #ffd9e1);color:var(--ai-chat-banner-text, #3f001b)}h1,h2,p{margin:0}h1,h2{font-weight:600;line-height:1.3}h1{font-size:1.25rem}h2{font-size:1.125rem;margin-bottom:.75rem}p{line-height:1.6}.banner p{margin-top:.75rem}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.6", ngImport: i0, type: ChatUiComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ai-chat-ui', imports: [NgTemplateOutlet], template: `
    <section class="chat-ui">
      <div class="banner">
        <h1>{{ bannerTitle() }}</h1>
        <p>{{ bannerDescription() }}</p>
      </div>
      @if (artifact(); as demoArtifact) {
        <section class="artifact">
          <h2>{{ demoArtifact.headline }}</h2>
          @if (renderer(); as demoRenderer) {
            <ng-container
              [ngTemplateOutlet]="demoRenderer"
              [ngTemplateOutletContext]="{ $implicit: demoArtifact }"
            />
          } @else {
            <p class="fallback">Vorschau nicht verfügbar.</p>
          }
        </section>
      }
    </section>
  `, styles: [":host{display:block;min-width:0;font:inherit}.chat-ui{display:grid;gap:1.5rem;background:var(--ai-chat-background, #fff8f8);color:var(--ai-chat-text, #21191c);overflow-wrap:anywhere}.banner{padding:1.25rem;border-radius:1rem;background:var(--ai-chat-banner-background, #ffd9e1);color:var(--ai-chat-banner-text, #3f001b)}h1,h2,p{margin:0}h1,h2{font-weight:600;line-height:1.3}h1{font-size:1.25rem}h2{font-size:1.125rem;margin-bottom:.75rem}p{line-height:1.6}.banner p{margin-top:.75rem}\n"] }]
        }], propDecorators: { bannerTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "bannerTitle", required: true }] }], bannerDescription: [{ type: i0.Input, args: [{ isSignal: true, alias: "bannerDescription", required: true }] }], artifact: [{ type: i0.Input, args: [{ isSignal: true, alias: "artifact", required: false }] }], renderer: [{ type: i0.Input, args: [{ isSignal: true, alias: "renderer", required: false }] }] } });

class ChatDemoRendererDirective {
    template = inject(TemplateRef);
    static ngTemplateContextGuard(_directive, _context) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.6", ngImport: i0, type: ChatDemoRendererDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.6", type: ChatDemoRendererDirective, isStandalone: true, selector: "ng-template[aiChatDemoRenderer]", exportAs: ["aiChatDemoRenderer"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.6", ngImport: i0, type: ChatDemoRendererDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[aiChatDemoRenderer]',
                    exportAs: 'aiChatDemoRenderer',
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ChatDemoRendererDirective, ChatUiComponent };
//# sourceMappingURL=ai-service-chat-ui.mjs.map
